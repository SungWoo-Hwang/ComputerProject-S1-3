package co.kr.sky.foodtruck.common;

//push계정 : seang0510@gmail.com
//push server key : AAAAzXxD5AA:APA91bHPX6lvQfBxn2M7Eprg7JhkFQ_siG7HaeqJ1WUZ6-YRJSr_nEu81uZgcOCKHC36Za5Ah2DNHHIXFfEyI3filz4GcGuU4SXxQWUuNzZCOt2PrZOLTG3S_a56nf0qtEvTwBfkGVJx
public class DEFINE {


    //Test
//    public static final String SERVER_URL                       = "http://snap40.cafe24.com/fobltalk/sample.php";

    //REAL
    public static final String SERVER_URL                   = "https://snap50.cafe24.com/FoodTruck/web/api";



    public static final String MEMBER_REGISTER                      = "/member/register.php";
    public static final String MEMBER_LOGIN                         = "/member/login.php";
    public static final String MEMBER_MAP_UPDATE                    = "/member/member_map_update.php";
    public static final String MEMBER_ON_OFF                        = "/member/member_on_off.php";
    public static final String MEMBER_MENU_INSERT                        = "/member/member_menuInsert.php";
    public static final String MEMBER_INTRODUCE                        = "/member/member_introduce.php";
    public static final String MEMBER_INFO_UPDATE                        = "/member/member_info_update.php";
    public static final String MEMBER_HOOGI_SELECT                        = "/member/hoogi_select.php";
    public static final String MEMBER_ORDER_LIST                        = "/member/order_list.php";

    //customer
    public static final String CUSTOMER_SEL_MAP                        = "/customer/sel_map.php";
    public static final String CUSTOMER_SEL_MENU                        = "/customer/sel_menu.php";
    public static final String CUSTOMER_ORDER_MENU                        = "/customer/order_menu.php";
    public static final String CUSTOMER_ORDER_LIST                        = "/customer/order_list.php";
    public static final String CUSTOMER_HOOGI_INSERT                        = "/customer/hoogi_insert.php";
    public static final String CUSTOMER_HOOGI_SELECT                        = "/customer/hoogi_select.php";



}