package com.example.fooduserapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddressMap extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.address_map);
    }
}
