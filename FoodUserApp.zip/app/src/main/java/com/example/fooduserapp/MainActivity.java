package com.example.fooduserapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Button signUpButton,findIdButton,findPwButton,loginButton;
    public static final int sub = 1001;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("로그인 페이지");

        signUpButton = (Button)findViewById(R.id.signUpButton);
        findIdButton = (Button)findViewById(R.id.findIdButton);
        findPwButton= (Button)findViewById(R.id.findPwButton);
        loginButton=(Button)findViewById(R.id.loginButton);

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),SignUp.class);
                startActivityForResult(intent,sub);//액티비티 띄우기
            }
        });
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Main2Activity.class);
                startActivityForResult(intent,sub);//액티비티 띄우기
            }
        });
    }

}
